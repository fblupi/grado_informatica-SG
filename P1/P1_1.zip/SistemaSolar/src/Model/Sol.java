
package Model;

public class Sol extends Astro {

    public Sol(float diametro, long velRotacion, String textura) {
        super(diametro, 0l, velRotacion, 0f, textura);
    }
    
}
